#!/bin/bash 
#tc32-elf-size $1 $2
python ../../$3/TlsrMemInfo.py $2
